from flask_sqlalchemy import SQLAlchemy
#Initlaize the Flask-SQLAlchemy extenstion instance

db = SQLAlchemy()
